//import the recently installed dependency

//Basic packages
const express = require('express')
require('dotenv').config()


//Create an instace of ExpressJS like this.
const app = express()

//Create a simple route for the server and assign a port to listen
const port = 5000

app.get("/",(req,res)=>{
res.send("hola")
})

///App listening on port
app.listen(process.env.PORT || port, ()=>{
console.log(`Server is running on port: ${process.env.PORT || port}`)
})
/*
Observe that, first we select in wich port we want to listen int he declaration const port.
then in app.get, we have passed 2 parameters. The first one that defines the route tha servers is "expecting", in this case "/", this means "http://ADDRESS:5000". The second one a callback to handle the request and response. If you remember, it is  in the same way we did when creted the simple server. In this case if someone visits the url, we will send the string hola to the browser.
finally,  in app.listen, we instruct our server to start listening in a dedicated port, in this case 5000.
*/


// import novice.js
//Import opur custom modules-controllers
const novice= require("./routes/novice")
//Routes
app.use('/novice', novice);

// // import dbConn.js
// //Import opur custom modules-controllers
// const dbConn= require("./DB/db")
// //Routes
// app.use('/db', dbConn);