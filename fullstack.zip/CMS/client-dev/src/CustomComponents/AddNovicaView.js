import axios from 'axios'
import React from 'react'

class AddNovicaView extends React.Component
{

   constructor(props) {
      super(props)
      this.state={
         novica:{}
      }
   }

   QGetTexFromField=(e)=>{
      this.setState(prevState=>({
         novica:{...prevState.novica, [e.target.name]:e.target.value}
      }))
   }

   QPostNovica=()=>{
      axios.post("http://88.200.63.148:5075/novice", {
         title:this.state.novica.title,
         slug:this.state.novica.slug,
         text:this.state.novica.text
      })
      .then(response=>{
         console.log("Send to server...")
      }).catch(err=>{
         console.log("Error!")
      })
   }

 render(){
    return(
        
         <div className="card" style={{margin:"10px"}}>
            <h3 style={{margin:"10px"}}>Welcome {this.props.QUserName}</h3>
            <div className="mb-3" style={{margin:"10px"}}>
            <label  className="form-label">Title</label>
            <input onChange={(e)=>this.QGetTexFromField(e)} name="title" type="text" class="form-control"  placeholder="Title..."/>
            </div>
            <div className="mb-3" style={{margin:"10px"}}>
            <label  className="form-label">Slug</label>
            <input onChange={(e)=>this.QGetTexFromField(e)}name="slug" type="text" class="form-control"  placeholder="Slug..."/>
            </div>
            <div class="mb-3" style={{margin:"10px"}}>
            <label  class="form-label">Text</label>
            <textarea onChange={(e)=>this.QGetTexFromField(e)} name="text" class="form-control" rows="3"></textarea>
            </div>
            <button  onClick={()=>this.QPostNovica()} className="btn btn-primary bt" style={{margin:"10px"}}>Send</button>
       </div>
    )
 }
}

export default AddNovicaView