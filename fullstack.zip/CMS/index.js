const express=require('express')
require('dotenv').config()
const cors = require('cors')
const cookieParser = require('cookie-parser')
const session = require('express-session')

const app=express()
const port=5075

//Configs
app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.use(cors({
    origin:['https://88.200.63.148:3080'],
    methods:['GET', 'POST'],
    credentials:true
}))
app.use(cookieParser("somesecret"))
app.use(session({
    secret:"somesecret",
    resave:true,
    saveUninitialized:true,
    cookie:{expires:60*2}
}))

//My custom routes
const novice =require('./routes/novice')
const users=require('./routes/users')

//when client visits home
app.get('/', (req,res)=>{
    res.send("Hola")
    res.end()  
})

app.use('/novice',novice)
app.use('/users', users)

app.listen( process.env.PORT || port,()=>{
    console.log(`Server is running on port: ${process.env.PORT || port}`)
})